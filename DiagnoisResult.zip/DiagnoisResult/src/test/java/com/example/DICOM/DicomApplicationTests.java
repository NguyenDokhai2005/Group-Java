package com.example.DICOM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DicomApplicationTests {

	@Test
	void contextLoads() {
	}

}
