package com.example.DICOM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DicomApplication {

	public static void main(String[] args) {
		SpringApplication.run(DicomApplication.class, args);
	}

}
