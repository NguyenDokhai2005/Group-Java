package Entity.Controller;

import com.example.DICOM.Entity.DiagnosisResult;
import Entity.Service.DiagnosisResultService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/diagnosis")
public class DiagnosisResultController {

    private final DiagnosisResultService diagnosisResultService;

    @Autowired
    public DiagnosisResultController(DiagnosisResultService diagnosisResultService) {
        this.diagnosisResultService = diagnosisResultService;
    }

    @PostMapping("/add")
    public DiagnosisResult addDiagnosisResult(@RequestBody DiagnosisResult diagnosisResult) {
        return diagnosisResultService.saveDiagnosisResult(diagnosisResult);
    }
}
