package Entity.Service;

import com.example.DICOM.Entity.DiagnosisResult;
import Entity.Repository.DiagnosisResultRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DiagnosisResultService {

    private final DiagnosisResultRepository diagnosisResultRepository;

    @Autowired
    public DiagnosisResultService(DiagnosisResultRepository diagnosisResultRepository) {
        this.diagnosisResultRepository = diagnosisResultRepository;
    }

    public DiagnosisResult saveDiagnosisResult(DiagnosisResult diagnosisResult) {
        return diagnosisResultRepository.save(diagnosisResult);
    }
}
